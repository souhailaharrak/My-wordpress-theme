(function () {



	document.addEventListener('DOMContentLoaded', function () {

	});

	(function ($) {
		$(document).ready(function () {

		});

	})(jQuery);
})();